#!/bin/bash


autoreconf -v --install
./configure --disable-shared --enable-static
make -j8


